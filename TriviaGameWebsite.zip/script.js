function login() {
  const username = document.getElementById("username").value.trim();
  if (username) {
    localStorage.setItem("trivia_user", username);
    alert("Welcome, " + username + "!");
  } else {
    alert("Please enter a username.");
  }
}

function startQuiz() {
  const user = localStorage.getItem("trivia_user");
  if (!user) {
    alert("Please log in first.");
    return;
  }
  window.location.href = "quiz.html";
}